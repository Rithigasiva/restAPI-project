# e2d74a24-f2c4-449a-bbf9-b240897df606-527f3694-0e27-4718-8fb0-1c0f5e8d6932
Repository for Teams Project code and project management
